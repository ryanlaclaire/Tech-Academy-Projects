﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExportTo_Excel_or_Pdf.Models
{
    public class Employee
    {
        public int id { get; set; }
        public string Expectation { get; set; }
    }
}