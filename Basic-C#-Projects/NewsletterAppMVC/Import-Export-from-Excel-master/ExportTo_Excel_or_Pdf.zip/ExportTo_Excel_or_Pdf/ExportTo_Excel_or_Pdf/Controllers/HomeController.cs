﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExportTo_Excel_or_Pdf.Models;
using System.IO;
using System.Data;
//using Excel;
//using System.Text;
using System.Web.UI;


namespace ExportTo_Excel_or_Pdf.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {
            ViewBag.EmployeeList = "";
            return View();
        }

        public ActionResult Import(FormCollection formCollection)
        {
            if (Request != null)
            {
                DataTable dt = new DataTable();
                HttpPostedFileBase file = Request.Files["UploadedFile"];
                if ((file != null) && (file.ContentLength > 0) && !string.IsNullOrEmpty(file.FileName))
                {
                    string fileName = file.FileName;
                    string path = Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["XlsFilePath"] + fileName);
                    file.SaveAs(path);
                    if (!System.IO.Directory.Exists(Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["XlsFilePath"])))
                    {
                        System.IO.Directory.CreateDirectory(Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["XlsFilePath"]));
                    }
                    var excelData = new ExcelData(path);
                    var sData = excelData.getData("Sheet1");
                    List<Employee> list = new List<Employee>();
                    dt = sData.CopyToDataTable();
                    foreach (DataRow item in dt.Rows)
                    {
                        Employee emp = new Employee();
                        emp.id = Convert.ToInt32(item["id"]);
                        emp.Expectation = item["Expectation"].ToString();
                        list.Add(emp);
                    }
                    ViewBag.EmployeeList = list;
                    TempData["EmployeeList"] = list;
                }
            }
            return View("Index");
        }

        public ActionResult Export()
        {
            List<Employee> emps = TempData["EmployeeList"] as List<Employee>;
            var grid = new System.Web.UI.WebControls.GridView();
            grid.DataSource = emps;
            grid.DataBind();
            Response.ClearContent();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment; filename=Expectations.xls");
            Response.ContentType = "application/ms-excel";
            Response.Charset = "";
            StringWriter sw = new StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            grid.RenderControl(htw);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
            ViewBag.EmployeeList = emps;
            return View("Index");
        }
    }
}